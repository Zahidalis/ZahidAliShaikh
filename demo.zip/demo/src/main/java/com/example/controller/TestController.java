package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.Employee;
import com.example.repository.EmployeeRepository;

@RestController
@RequestMapping("/api")
public class TestController {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@GetMapping("/employee")
	public List<Employee> getEmployee(){
		
		List<Employee> empList = new ArrayList<Employee>();
		empList = employeeRepository.findAll();
		return empList;
		
		
	}
	
	@PostMapping("/employees")
	public Employee createEmp(@RequestBody Employee employee) {
		
		employeeRepository.saveAndFlush(employee);
		return employee;
	}
	
	@PutMapping("/employees/{id}")
	public Employee updateEmp(@RequestBody Employee employee, @PathVariable int id) {
		employeeRepository.saveAndFlush(employee);
		return employee;
	}
	
	@DeleteMapping
	@PostMapping("/employees/{id}")
	public Employee deleteEmp(@PathVariable long id) {		
		Employee emp = employeeRepository.getById(id);
		employeeRepository.delete(emp);
		return emp;
	}

}
